                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2149867
anet a8 y belt tensioner by CH35C0 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I redid this because the original one didn't fit my printer for a mm in the z axis (the arms should be 7.25 with a gap of 12mm and they were off).
The design is using the same system (so I'm keeping the plate and screw that I had already printed from elfco's version and discarding the arms that didn't fit) and mixed it with the original that came in the printer in Illustrator.

After printing I olnly had to remove the raft (the one created in MatterControl only needed a snap...it was awesome and really smooth) and it fit perfectly.


ADVICE: some people have trouble with the screw and plate which where designed by elfco, so they recommend to scale on the X and Y the screw to make it smaller but not on the Z.
As aforementioned, I didn't have any issue with his screw and plate, only had to screw and unscrew a few times to losen it a little



# Print Settings

Printer: Anet A8
Rafts: Doesn't Matter
Supports: Yes
Resolution: 0.1
Infill: 20

Notes: 
first print sliced in MatterControl and the result was awesome!
perfectly smooth and with the supports being the easiest ones to remove for now (way better than cura or slic3r and more or less like simplify3d)

EDIT: larger union between the thread and the thumb screw as asked. 
EDIT: larger screw as asked